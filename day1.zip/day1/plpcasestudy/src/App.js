import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { Login } from './Components/Login';
import Register from './Components/Register';
import{BrowserRouter as Router,Route,Link,Switch} from 'react-router-dom';
import Header from './Components/Header';
import Home from './Components/Home';
import Profile from './Components/Profile';

class App extends Component {
  render() {
    return (
      <Router>
      <div>
        
        <Header/>
        <div className="container">
        <Switch>
        
         <Route exact path="/login" component={Login}/>
         <Route exact path="/" component={Home}/>
         <Route exact path="/register" component={Register}/>
         <Route exact path="/profile" component={Profile}/>
   
        </Switch>
        
        </div>
      </div>
    </Router>

    );
  }
}

export default App;
