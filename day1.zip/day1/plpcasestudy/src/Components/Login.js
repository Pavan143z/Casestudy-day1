import React from "react";
import {Link} from 'react-router-dom';
export class Login extends React.Component {
    constructor() {
        super();
        this.state = {
            user: {
                userName: "",
                passWord: ""
            },

            display: false,
            view: true
        };
    }
    UpdateState(ctrl, value) {
        const { user } = this.state; //get current state
        user[ctrl] = value; //update the user entered data
        this.setState({ user });}
    handleSubmit(e) {
        e.preventDefault();
        alert('login successful')
        alert(`${this.state.user.userName}`);
        this.setState({ display: true });
        this.setState({ view: false });
    }
    render() {
        const { user } = this.state;    
        return (
            <div className="clg col-6">
                <h1> Login </h1>
                <form >
                    <div className="form-group">
                        <label className="text text-info"> Username: </label>
                        <input
                            type="text"
                            className="form-control"

                        />
                    </div>
                    <div className="form-group">
                        <label className="text text-info"> Password: </label>
                        <input
                            type="text"
                            className="form-control"
                        />
                    </div>
                    <div className="form-group">
                        
                        <Link  type="submit" to="/profile" className="btn btn-link">Login</Link>
                    </div>
                </form>
            </div>
        );
    }
}


export default Login;
