import React from 'react'
export class Home extends React.Component{
 render(){
     return(
         <div>
         <h1>Welcome to Home Page</h1>
        
         </div>
     )
 }
}
export default Home;