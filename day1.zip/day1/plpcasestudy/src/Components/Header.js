import React from 'react'

import {Link} from 'react-router-dom';

export const Header = () => {

return ( 

<nav className="navbar navbar-expand-lg navbar-light bg-light">

<div className="container-fluid">

<div className="navbar-header">


<Link className="navbar-brand" to="/">Brand</Link>

</div>

<div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

<ul className="nav navbar-right">

<li className="active"><Link to="/">Home
<span className="sr-only">

</span></Link></li>
</ul> 
<hr/>
<ul className="nav navbar-nav navbar-right">
<li ><Link to="/login">Login</Link></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<li ><Link to="/register">Register</Link></li>

</ul>







<ul className="nav navbar-nav navbar-right">

{/* <li><Link to="/login">Login</Link></li> */}

</ul>

</div>

</div>

</nav>

);

}


export default Header;