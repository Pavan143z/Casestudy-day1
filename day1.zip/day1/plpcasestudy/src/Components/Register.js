import React from "react";
import {Link} from 'react-router-dom';
import { Redirect } from "react-router";
class Signup extends React.Component {
  

  render() {
  

    return (
      <div className="clg col-6">
        <h1>Register</h1>

        <form >
          <div className="form-group">
            <label>FistName: </label>
            <input
              type="text"
              className="form-control"
              
            />
          </div>
          <div className="form-group">
            <label> LastName:</label>
            <input
              type="text"
              className="form-control"
             
            />
          </div>
          <div className="form-group">
            <label> UserName:</label>
            <input
              type="text"
              className="form-control"
             
            />
          </div>
          <div className="form-group">
            <label>Email: </label>
            <input
              type="text"
              className="form-control"
             
            />
          </div>
           <div className="form-group">
            <label>Password: </label>
            <input
              type="text"
              className="form-control"
             
            />
          </div>
          <div className="form-group">
            
            <Link  type="submit" to="/login" className="btn btn-link">SignUp</Link>
          </div>
        </form>
      </div>
    );
  }
}

export default Signup;
