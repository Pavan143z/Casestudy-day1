import React from 'react'
export class Profile extends React.Component{
 render(){
     return(
         <div>
         <h1>Welcome to Profle page</h1>
        
         </div>
     )
 }
}
export default Profile;