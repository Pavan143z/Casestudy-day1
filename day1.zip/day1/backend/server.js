const express= require('express');
const mongoose =require('mongoose')
const cors= require('cors')
const bodyparser= require('body-parser')
 

const app=express()
var port =process.env.PORT || 5000



app.use(cors())
app.use(bodyparser.urlencoded({extended: false}))
app.use(bodyparser.json())




const mongoURI='mongod://localhost:27017/mernloginreg'

mongoose
.connect(mongoURI,{userNewUrlParser:true})
.then(()=>console.log("MongoDb Connected"))
.catch(err=>console.log(err))

var Users=require('./routes/Users')
app.listen(port,()=>{
    console.log("Server is running on port:"+ port)
})